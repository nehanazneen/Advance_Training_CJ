package com.problemstatement_10;
import java.util.Scanner;

public class Strings {

	
	public static boolean isInterleaving(String X, String Y, String Z)
	{
		
		if (X.length() == 0 && Y.length() == 0 && Z.length() == 0) {
			return true;
		}

		if (Z.length() == 0) {
			return false;
		}


		boolean x = (X.length() != 0 && Z.charAt(0) == X.charAt(0)) &&
				isInterleaving(X.substring(1), Y, Z.substring(1));


		boolean y = (Y.length() != 0 && Z.charAt(0) == Y.charAt(0)) &&
				isInterleaving(X, Y.substring(1), Z.substring(1));

		return x || y;
	}

	public static void main(String[] args)
	{
		
		
		@SuppressWarnings("resource")
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter The First String :");
		String X=scan.nextLine();
		System.out.println("Enter The Second String :");
		String Y=scan.nextLine();
		System.out.println("Enter The Third String :");
		String Z=scan.nextLine();		
		

		if (isInterleaving(X, Y, Z)) {
			System.out.print("True:String is Interleaving");
		}
		else {
			System.out.print("False: string is not interleaving");
		}
	}
}