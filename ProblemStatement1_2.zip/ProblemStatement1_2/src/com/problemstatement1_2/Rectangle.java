package com.problemstatement1_2;
import java.util.Scanner;
public class Rectangle {
	int length; 
    int breadth; 
    int area;
   
    public Rectangle()
    {
    	length = 0;
    	breadth= 0;
    }

    void input() {
        @SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
        System.out.print("Enter the length of rectangle: ");
        length = scan.nextInt();
        System.out.print("Enter the breadth of rectangle: ");
        breadth = scan.nextInt();
    }

    void calculate() {
        area = length * breadth;
        
    }

    void display() {
        System.out.println("Area of The Rectangle = " + area);
        System.out.println("Rectangle has four sides");
    	System.out.println("In rectangle two sides are equal");
    	System.out.println("Rectangle has length and breadth");
       
    }
	public static void main(String[] args) {
		    Rectangle object1 = new Rectangle();
		    object1.input();
		    object1.calculate();
		    object1.display();
	        System.out.println();
	        Rectangle object2 = new Rectangle();
	        object2.input();
	        object2.calculate();
	        object2.display();
	        System.out.println();
	        Rectangle object3 = new Rectangle();
	        object3.input();
	        object3.calculate();
	        object3.display();
	        System.out.println();
	        Rectangle object4 = new Rectangle();
	        object4.input();
	        object4.calculate();
	        object4.display();
	        System.out.println();
	        Rectangle object5 = new Rectangle();
	        object5.input();
	        object5.calculate();
	        object5.display();

	}

}
