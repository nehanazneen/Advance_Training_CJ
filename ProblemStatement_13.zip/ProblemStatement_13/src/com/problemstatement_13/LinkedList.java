package com.problemstatement_13;

public class LinkedList {

	Node head; 
	class Node 
	{
		int data;
		Node next;
		Node(int d)
		{
			data = d;
			next = null;
		}
	}
	void printNthFromEnd(int n)
	{
	    Node ptr1 = head;
        Node ptr2 = head;
 
        int count = 0;
        if (head != null)
        {
            while (count < n)
            {
                if (ptr2 == null)
                {
                   System.out.println("-1");
                   System.out.println(n+ "th node from the last doesnt exist");
                    return;
                }
                ptr2 = ptr2.next;
                count++;
            }
 
            if(ptr2 == null)
            {
              head = head.next;
              if(head != null)
                System.out.println(n +"th node from the last is "+head.data);
            }
            else
            {
                   
              while (ptr2 != null)
              {
                  ptr1 = ptr1.next;
                  ptr2 = ptr2.next;
              }
              System.out.println(n +"th node from the last is "+ptr1.data);
            }
        }
	
	}
	public void add(int newData)
	{
		Node newNode = new Node(newData);
		newNode.next = head;
		head = newNode;
	}
	public static void main(String[] args)
	{
		LinkedList ll = new LinkedList();
		ll.add(10);
		ll.add(5);
		ll.add(100);
        ll.add(5);
        ll.printNthFromEnd(5);
        
		LinkedList ll1 = new LinkedList();
		ll1.add(9);
		ll1.add(8);
		ll1.add(7);
        ll1.add(6);
        ll1.add(5);
		ll1.add(4);
		ll1.add(3);
        ll1.add(2);
        ll1.add(1);
        ll1.printNthFromEnd(2);
        
	}
}