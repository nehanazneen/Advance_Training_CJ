package com.problemstatement2_2;

class AcceptsTwoNumbers {
	  public static void main(String[] args) {

	    int i = 1, n = 15, firstTerm = 1, secondTerm = 3;
	    System.out.println("Fibonacci Series till " + n + " terms are:");

	    while (i <= n) {
	      System.out.print(firstTerm + ", ");

	      int nextTerm = firstTerm + secondTerm;
	      firstTerm = secondTerm;
	      secondTerm = nextTerm;

	      i++;
	    }
	  }
	}
